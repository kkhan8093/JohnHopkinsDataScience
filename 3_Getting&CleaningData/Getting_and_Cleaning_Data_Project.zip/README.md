# Getting and Cleaning Data Course Project

This repository contains the solution for the Coursera Getting and Cleaning Data course project.

Files included:
- run_analysis.R
- tidy_data.txt
- CodeBook.md

Run source("run_analysis.R") from the UCI HAR Dataset directory to generate tidy_data.txt.