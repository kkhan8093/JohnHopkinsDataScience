# CodeBook

The data comes from the Human Activity Recognition Using Smartphones Dataset.

Subject: Identifier for each participant (1–30)
Activity: Descriptive activity name

Only mean and standard deviation measurements were retained.
The final tidy data set contains the average of each variable for each activity and each subject.