library(dplyr)

x_train <- read.table("train/X_train.txt")
y_train <- read.table("train/y_train.txt")
subject_train <- read.table("train/subject_train.txt")

x_test <- read.table("test/X_test.txt")
y_test <- read.table("test/y_test.txt")
subject_test <- read.table("test/subject_test.txt")

x_data <- rbind(x_train, x_test)
y_data <- rbind(y_train, y_test)
subject_data <- rbind(subject_train, subject_test)

features <- read.table("features.txt")
feature_names <- features$V2
colnames(x_data) <- feature_names

mean_std_indices <- grep("mean\(\)|std\(\)", feature_names)
x_data <- x_data[, mean_std_indices]

activity_labels <- read.table("activity_labels.txt")
colnames(activity_labels) <- c("ActivityID", "ActivityName")
y_data$V1 <- activity_labels$ActivityName[y_data$V1]

colnames(subject_data) <- "Subject"
colnames(y_data) <- "Activity"

clean_data <- cbind(subject_data, y_data, x_data)

names(clean_data) <- gsub("\\()", "", names(clean_data))
names(clean_data) <- gsub("-", "_", names(clean_data))
names(clean_data) <- gsub("^t", "Time_", names(clean_data))
names(clean_data) <- gsub("^f", "Frequency_", names(clean_data))

tidy_data <- clean_data %>%
  group_by(Subject, Activity) %>%
  summarise(across(everything(), mean))

write.table(tidy_data, "tidy_data.txt", row.names = FALSE)